# Arquitectura observada en copias HTML históricas (NO PRODUCCIÓN)

- Los archivos HTML inspeccionados incluyen estilos CSS y scripts JavaScript integrados: no contienen importaciones de paquetes NPM ni una estructura fuente multiarchivo en estos documentos.
- Se observó código de almacenamiento local del navegador (`localStorage`, `sessionStorage`), exportación de datos JSON y una integración HTTP con Supabase (`auth/v1`, `rest/v1`, `functions/v1`).
- Aparecen referencias opcionales a Google Drive, inicio de sesión Google y funciones de IA. Algunos endpoints aparecen vacíos o desactivados en la copia HTML: **no se debe inferir el estado de producción**.
- Hay referencias a `./sw.js` (service worker) y `window.MareaNative` (puente Android), **no recuperados** entre estas copias HTML. En consecuencia, este paquete NO puede acreditar todos los componentes requeridos para ejecutar esas versiones plenamente.
- Se encontró en las copias HTML una URL de proyecto Supabase y una clave **publishable/anon (pública)** de cliente. No es una contraseña ni clave privada, pero puede apuntar a un backend remoto. Como se preservan los archivos históricos byte a byte, ese dato sigue dentro del HTML histórico; **no usar este paquete para probar contra producción ni publicarlo por error**. La existencia y permisos del servicio actual deben verificarse en la cuenta propietaria.
- No se identificaron valores de claves privadas ni contraseñas con las expresiones de reconocimiento usadas en este archivo. Esto no reemplaza una auditoría manual de secretos previa a GitHub.
- La estructura real de la aplicación en ChatGPT Sites, sus dependencias, permisos, datos subidos, variables y scripts no pudo establecerse desde estos archivos.

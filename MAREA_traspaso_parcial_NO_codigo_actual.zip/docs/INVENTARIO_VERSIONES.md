# MAREA — Inventario de versiones y plan de traspaso a GitHub

**Revisión:** 22 de noviembre de 2026.  
**Sitio facilitado:** https://marea.decentbun2048.chatgpt.site/  
**Alcance:** archivos localizados en la biblioteca de este ChatGPT y comparación estática de los HTML accesibles. **No se pudo abrir la versión publicada ni acceder a la sesión original de edición de Sites/Codex.** No confundir fecha del archivo con versión actualmente publicada.

## Decisión principal

**No reemplazar MAREA por el HTML más nuevo ni por un ZIP histórico.** Primero exportar el código real del ChatGPT Site publicado, respaldar datos y archivos del servicio por separado, y comparar su aspecto y comportamiento con la versión visualmente aprobada. Conservar las versiones históricas como referencia.

## Documentos maestros identificados

- `Apps terapia/MAREA_PROMPT_ASTRA_CORREGIDO_HOW_WE_FEEL.md` — especificación más extensa localizada (42 071 bytes; 21 nov., 21:56 UTC). Prioritaria como **requisitos y decisiones**, no como prueba de implementación.
- `Apps terapia/MAREA_PROMPT_COMPLETO_PARA_ASTRA.md` — especificación anterior (27 804 bytes; 21 nov., 20:08 UTC).
- `Apps terapia/MAREA_PROMPT_CORREGIDO_INTEGRAL_PARA_SOL.md` — instrucciones históricas para mantener diseño.
- `Apps terapia/MAREA_reporte_tecnico_de_bugs_v06.md` y `MAREA_v06_parche_errores_verificados.patch` — auditoría y parche para un prototipo **0.6**, no para aplicar sin comparar el código vigente.
- `AGENTS.md` — archivo de instrucciones de Codex preparado previamente; es una **guía preliminar**, y debe remitir al prompt maestro citado arriba.
- Los ZIP `MAREA_ASTRA_HOW_WE_FEEL_PROMPT_COMPLETO_CORREGIDO.zip`, `MAREA_ASTRA_KIT_COMPLETO_SIN_REDISENO.zip` y `MAREA_SOL_PROMPT_INTEGRAL_FIEL_SIN_REDISENO.zip` son paquetes de requisitos y referencias: verificar su contenido antes de utilizarlos como código.

## Versiones históricas de código encontradas

| Familia | Archivos representativos | Observación |
|---|---|---|
| Inicial | `MAREA_demo.html`, `MAREA_web.zip`, `MAREA_codigo_completo.zip` | Primeras copias de aplicación. |
| 0.2 | `MAREA_v02_demo.html`, `MAREA_v02_codigo_completo.zip` | Histórica. |
| 0.4 | `MAREA_v04_demo.html`, `MAREA_v04_codigo_completo.zip` | Histórica; incluye material específico de gráficos. |
| 0.5 | `MAREA_web_diario_v05_demo.html`, `MAREA_web_diario_v05.zip` | Histórica; trabajo sobre diario. |
| 0.6 | `MAREA_v06_demo_un_archivo.html`, `MAREA_v06_web_para_Sol.zip`, `MAREA-0.6-revision-web.zip` | Histórica; tiene un informe de errores de esta línea. |
| Otra rama de diario | `MAREA_diario_fiel_emociones_y_momentos.html` | Prototipo específico de diario; no asumir que es el sitio principal. |

## Secuencia de HTML posteriores comparados estáticamente

Estos seis HTML contienen una aplicación amplia y comparten una base de código similar. Se compararon los cambios de texto/código entre cada par, pero no se ejecutaron pruebas completas en navegador.

1. `MAREA-registro-por-hora.html` (21 nov., 17:26 UTC): punto de partida de esta secuencia localizada.
2. `MAREA-vista-previa-descanso-DBT.html` (19:21): se incorporan estructuras para modo descanso y herramientas/ola emocional.
3. `MAREA-completa-Descanso-y-DBT.html` (19:48): amplía campos, elecciones y registros del descanso y de la ola emocional.
4. `MAREA-revision-Descanso-DBT-y-horas.html` (20:01): incorpora cambios de fecha/hora, «Sin hora» y momento del día subjetivo en el HTML.
5. `MAREA-prueba-web.html` (20:29): añade cambios en herramientas de resolución de problemas, importación/exportación y otros flujos.
6. `MAREA-revision-copias.html` (22:06): último HTML **de la secuencia** por fecha de modificación, con ajustes adicionales de importación/combinación de copias. **No está verificado que sea el sitio actual ni que resuelva todos los riesgos.**

Una pieza aparte, `MAREA-fichas-emocionales.html` (22:15), es un prototipo de fichas/definiciones emocionales; no representa por sí sola la app completa.

## Requisitos que se deben conservar

Según el prompt maestro: diseño aprobado (en particular versión 10 si existe), navegación y barra inferior originales, diario de cuatro preguntas, registro emocional con múltiples etiquetas y hora opcional, Modo Descanso reversible, herramientas DBT/CBT, personajes y alter egos, vidas simuladas, temas e idiomas, guardado seguro y protección de la privacidad. Las funcionalidades descritas en el prompt son **objetivos o requisitos**, no evidencia automática de que estén implementadas.

## Riesgos documentados en 0.6

Pérdida de texto al seleccionar imágenes de alter ego, horas inventadas, duplicados al guardar, fusiones incorrectas de copias, reemplazos sin respaldo verificable, posibles pérdidas por sincronización concurrente y diferencias frente al diseño aprobado. Algunos se corrigieron en un parche para 0.6; **no está comprobado que la versión pública los tenga o que ya estén resueltos allí**.

## Lo que se sabe sobre el enlace chatgpt.site

Es una URL de **ChatGPT Sites**, no un repositorio GitHub. OpenAI documenta que el propietario puede pedir a Codex que exporte el código fuente del sitio. Exportar código no restaura la base de datos ni los archivos subidos; restaurar una versión del sitio tampoco restaura automáticamente esos datos. La edición colaborativa del mismo Site se limita a miembros activos del mismo espacio de trabajo con permisos compatibles. Con **dos cuentas personales independientes**, compartir un GitHub privado permite desarrollar el código, pero **no transfiere por sí solo la propiedad ni el control de publicación en la URL original**.

Documentación oficial: https://help.openai.com/es-419/articles/20001339-creating-and-using-chatgpt-sites

## Paso siguiente, sin alterar producción

1. Desde la cuenta propietaria de MAREA, abrir **Sites → MAREA → Editar** o su conversación original.
2. Pedir a Codex: «Exportá una copia completa del código fuente ACTUAL de este Site, con estructura de carpetas, dependencias e instrucciones para ejecutarlo localmente. No cambies ni publiques el sitio. Excluí secretos y datos privados, y documentá qué servicio de base de datos/archivos usa y cómo respaldarlos de forma segura por separado».
3. Descargar y conservar la exportación intacta. Respaldar también datos/archivos del sitio de manera autorizada y segura, sin subir registros personales a GitHub.
4. Crear repositorio **privado** en GitHub y subir la exportación real como base. Agregar `AGENTS.md` en la raíz, el prompt maestro en `docs/REQUISITOS_MAREA.md`, este inventario en `docs/INVENTARIO_VERSIONES.md`, y archivos anteriores en `historico/` (si se quieren preservar).
5. Dar acceso de colaborador a la segunda cuenta GitHub. Conectar el repositorio al Codex de la segunda cuenta; trabajar en una rama y revisar cambios mediante pull requests.
6. **No publicar sobre la URL original** sin acceso y autorización en la cuenta o espacio de trabajo propietario de ese Site; validar cambios y respaldo de datos antes de publicar.

## Estructura sugerida en GitHub

```text
marea/
├── [código actual exportado del Site]
├── AGENTS.md
├── README.md
├── docs/
│   ├── REQUISITOS_MAREA.md
│   ├── INVENTARIO_VERSIONES.md
│   ├── ESTADO_REAL_Y_PENDIENTES.md
│   └── HISTORIAL_PROMPTS.md  # solo si se recuperan los mensajes originales
└── historico/                 # opcional: nunca usar como rama de producción
```

**Advertencias:** el contenido completo de las conversaciones con Codex no se transfiere automáticamente con la exportación del código ni con GitHub. Evitar subir exportaciones completas de ChatGPT, diarios personales, secretos, tokens o claves privadas al repositorio, aun siendo privado.

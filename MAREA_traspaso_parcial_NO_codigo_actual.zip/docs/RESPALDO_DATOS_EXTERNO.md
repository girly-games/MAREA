# Datos y archivos que no están contenidos en el código

**Aviso:** se identifican posibles servicios mediante los archivos HTML históricos; su uso en la versión de producción NO se verificó. No se ha extraído ni incluido ningún registro de personas usuarias.

| Capa | Dónde puede residir | Procedimiento independiente de respaldo |
|---|---|---|
| Base de datos nativa de ChatGPT Sites | Almacenamiento de la plataforma, si el Site la usa | Desde la sesión propietaria, pedir inventario de tablas y un mecanismo de exportación autorizado de datos; Sites no dispone de una función integrada de respaldo conjunto de BD y archivos. No ejecutar migraciones ni restauraciones durante la exportación. |
| Datos Supabase (en HTML histórico) | API de Supabase; aparece referencia a una tabla `marea_user_data` | En el proyecto Supabase autorizado, usar funciones de copia/exportación administradas por la persona propietaria; guardar esquema, políticas RLS y datos por separado, en destino cifrado. No subir un volcado con datos personales al repositorio. Confirmar si producción realmente usa ese proyecto. |
| Usuarios/sesiones | Supabase Auth y/o mecanismo real de inicio de sesión del Site | Respaldar únicamente configuración, proveedores y reglas de acceso (sin secretos). Tratar identidades y sesiones como datos sensibles: nunca copiarlas a GitHub. Los tokens no deben exportarse. |
| Archivos subidos | ChatGPT Sites uploads, Supabase Storage, Google Drive u otro servicio, solo si están implementados | Exportar los archivos con herramientas oficiales/autorizadas del proveedor a un respaldo privado cifrado. Conservar rutas, metadatos y permisos sin publicar datos personales. |
| Datos locales del navegador | `localStorage` y `sessionStorage` observados en HTML histórico | Si la app actual tiene “Exportar mis datos”, usarla **por cuenta y dispositivo** para generar un JSON privado, comprobar que se puede leer y guardarlo **fuera del repositorio**. No copiar sesiones ni tokens. |
| Google Drive | Existe lógica opcional de respaldo en HTML histórico, pero su endpoint de servicio está vacío | Verificar si está realmente conectado. Si lo está, respaldar por separado con permisos de la cuenta correspondiente; no incluir OAuth tokens ni identificadores privados en código. |
| Servicios de IA y endpoints | Configuración del proyecto, si existen | Documentar nombres de variables, nombres de funciones y permisos, no credenciales. Un endpoint de IA vacío en un prototipo no prueba que producción carezca de IA. |
| Configuración y secretos | Ajustes del Site, consola del proveedor, variables de entorno | Crear inventario de **nombres** de variables en `.env.example`, jamás los valores. Restablecer secretos manualmente en el entorno nuevo. |
| Contenido de chats / prompts y recursos creativos | Cuenta ChatGPT, Biblioteca y archivos adjuntos | Exportar solo material pertinente y aprobado, revisado para quitar información personal; no transferir el historial de conversaciones completo al repositorio. |

## Comprobación y custodia del respaldo

1. Conservar las exportaciones privadas cifradas fuera de GitHub (incluidos repositorios privados).
2. Validar tamaño, número de registros, suma de comprobación y acceso con permisos autorizados.
3. Guardar esquema de BD y migraciones en el proyecto sin datos reales; almacenar registros sensibles solo en un respaldo separado.
4. No compartir respaldos de diarios, síntomas, relatos personales u otros contenidos sensibles con Codex ni en issues/commits.
5. No borrar la instancia anterior ni el almacenamiento previo durante la transferencia.

Fuente oficial: https://help.openai.com/es-419/articles/20001339-creating-and-using-chatgpt-sites

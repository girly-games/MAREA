# Exportar la fuente real de MAREA desde ChatGPT Sites

## Paso esencial

El texto de la solicitud debe ejecutarse **en el chat de edición que tiene adjunto el Site de producción**, o desde **Sites → MAREA → Editar** en la cuenta propietaria. Un chat ordinario que solo conoce la URL no puede garantizar acceso al proyecto original.

### Prompt para ese chat / Codex

> Exportá una copia íntegra del código fuente del Site MAREA **actualmente guardado**, identificando el commit/versión de origen y el estado de despliegue. Conservá el árbol de carpetas y todos los archivos de código, recursos no privados, dependencias y lockfiles, scripts, esquemas/migraciones, pruebas y configuración de desarrollo que existan. Generá un ZIP descargable junto con `README.md` (cómo instalar y ejecutar), `.env.example` con **solo nombres de variables**, `MANIFEST.sha256` y un inventario de servicios externos (base de datos, storage, autenticación, IA y APIs). No sustituyas el código por prototipos ni recrees la aplicación. No cambies archivos, no corras migraciones, no publiques, no cambies permisos. Omití todas las claves privadas, contraseñas, tokens y datos personales. Señalá explícitamente qué parte no se pudo exportar.

## Validación antes de GitHub

- Comprobar que ZIP incluya los archivos principales del proyecto real, no solo código de una demo o vista compilada.
- Guardar el ZIP original sin editar en un dispositivo privado.
- Buscar secretos antes de subir. Excluir `.env`, service-role keys, tokens OAuth, claves de proveedor IA, credenciales de base de datos, respaldos JSON, documentos personales y archivos de usuarios.
- No considerar anónimos los diarios y registros solo porque se hayan quitado nombres: pueden contener información sensible.
- Leer el README y probar únicamente en una configuración aislada, sin apuntar a la base de datos de producción.
- GitHub privado no implica transferencia de propiedad de ChatGPT Sites ni de su URL de despliegue.

## Fuente de referencia

OpenAI Help Center, “Crear y usar ChatGPT Sites”: https://help.openai.com/es-419/articles/20001339-creating-and-using-chatgpt-sites

Indica que el propietario puede pedir a Codex la exportación del código fuente y que restaurar una versión no restaura la base de datos ni los archivos subidos.

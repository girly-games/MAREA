# MAREA — paquete de traspaso parcial (NO es el código actual confirmado)

**Fecha:** 22 de noviembre de 2026.  
**Sitio:** https://marea.decentbun2048.chatgpt.site/  
**Estado:** documentación + copias históricas, sin conexión con el árbol de fuentes del Site original.  
**NO APTO PARA DECLARARLO COMO RELEASE DE PRODUCCIÓN.**

## Qué contiene

- `historico_no_verificado/`: siete archivos HTML originales, copiados **byte a byte**, sin cambios en su interfaz, contenido ni lógica. Se incluyen solo como antecedentes de código, no como evidencia de implementación del Site actual.
- `AGENTS.md`: instrucciones preliminares previamente elaboradas para Codex; no sustituyen la revisión del proyecto real.
- `docs/INVENTARIO_VERSIONES.md`: antecedentes y advertencias acerca de MAREA.
- `docs/EXPORTAR_SITE_REAL.md`: procedimiento para conseguir el código real y trasladarlo a un GitHub privado.
- `docs/RESPALDO_DATOS_EXTERNO.md`: qué queda fuera del código y cómo respaldarlo de manera separada.
- `docs/ARQUITECTURA_HTML_HISTORICO.md`: dependencias observadas solo en las copias HTML; no constituyen un inventario de producción.
- `docs/MANIFEST.json`: hashes SHA-256 y tamaños de los originales para verificar integridad.
- `.gitignore`: exclusiones recomendadas para secretos y datos privados.

## Limitación crítica

No se dispone aquí del repositorio raíz ni de la sesión original de edición del ChatGPT Site actual. Se pudo ver el enlace publicado, pero **no recuperar su árbol fuente**. Tampoco se obtuvieron los datos remotos ni los archivos subidos por usuarios. Ninguna de las copias históricas puede reemplazar la publicación sin comparación exhaustiva.

## Ejecución SOLO para inspección de los HTML históricos

Estos prototipos contienen HTML/CSS/JavaScript integrados. No se ha encontrado un `package.json` ni un instalador de dependencias para ellos; eso **no describe las dependencias del Site actual**.

Se pueden inspeccionar los archivos HTML en un editor de texto. Para abrirlos con un servidor local en un entorno de desarrollo aislado:

```bash
cd historico_no_verificado
python3 -m http.server 8000 --bind 127.0.0.1
```

Después se abre `http://127.0.0.1:8000/MAREA-revision-copias.html` solo para inspeccionar. **ADVERTENCIA:** esa copia incorpora referencias a un servicio Supabase remoto y usa APIs de autenticación/sincronización. No iniciar sesión, sincronizar ni generar datos de prueba contra el servicio de producción. Primero aislar cualquier backend en una copia de trabajo, no en estos originales. Hay componentes opcionales ausentes, como `sw.js` y un puente nativo de Android; no se garantiza que todos los flujos funcionen.

## Handoff correcto

1. En la cuenta original de ChatGPT, abrir `Sites → MAREA → Editar` para obtener el Site real en el contexto de Codex.
2. Solicitar **solo exportación**, sin cambios ni publicación, del árbol actual completo con archivos de configuración, lockfiles, migraciones, assets no privados y README de ejecución.
3. Inspeccionar las credenciales y los datos de usuarios antes de comprimirlo; nunca compartir secretos ni registros privados.
4. Conservar la exportación original intacta como referencia, y crear un repositorio GitHub **privado** desde esos archivos reales. No usar estos HTML como punto de partida para reemplazar producción.
5. Conectar la segunda cuenta ChatGPT/Codex al repositorio GitHub, trabajar en una rama y revisar cada cambio; la propiedad y publicación de la URL original no pasan con GitHub.

## Nada se modificó

Este paquete se preparó exclusivamente a partir de copias preexistentes. No se editó el Site, no se cambió su interfaz ni se efectuó ningún despliegue o operación sobre sus datos.

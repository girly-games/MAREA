# MAREA — Instrucciones para Codex

> Documento inicial preparado a partir de copias HTML y materiales de diseño de MAREA disponibles en la conversación. **No sustituye el historial original de prompts ni confirma cuál es la versión más reciente del proyecto.** Antes de modificar código, contrastar estas instrucciones con el repositorio vigente y con la responsable del proyecto.

## Qué es MAREA

MAREA es una aplicación educativa y de exploración personal enfocada en habilidades y herramientas de bienestar emocional. En versiones HTML del proyecto se observan contenidos bilingües español/inglés, ejercicios vinculados a DBT y CBT, registros de emociones, diario, escenarios y juegos de decisiones, personalización y una modalidad de descanso. Se han trabajado también prototipos de fichas para comprender emociones.

## Prioridades

1. **Conservar lo existente.** Antes de cambiar algo, inspeccionar el proyecto, describir su estructura y establecer qué funciones ya existen. No rehacer la aplicación desde cero ni reorganizarla de forma masiva sin aprobación.
2. **Respetar el estilo y la voz.** Mantener una interfaz sobria, clara, accesible y no invasiva. Respetar los contenidos y términos en español rioplatense cuando estén presentes, y conservar su alternativa en inglés.
3. **Privacidad por defecto.** No registrar, imprimir, publicar ni subir al repositorio datos personales de usuarios, diarios privados, contraseñas, tokens ni claves secretas. Revisar antes de cada commit. Si hay integración con Supabase u otros servicios, distinguir configuración pública de credenciales privadas.
4. **Accesibilidad.** Mantener navegación por teclado, etiquetas comprensibles, contraste suficiente, estados de foco visibles y soporte para dispositivos móviles. Evitar interacciones obligatorias o animaciones que no se puedan reducir.
5. **Contenido responsable.** Presentar las actividades como recursos educativos, no como diagnósticos ni sustitutos de atención profesional. Evitar afirmaciones clínicas infundadas.
6. **Cambios pequeños y comprobables.** Trabajar en una rama nueva, informar archivos modificados, explicar efectos sobre la funcionalidad existente y probar antes de proponer la incorporación de cambios.

## Antes de empezar cualquier tarea

- Identificar el archivo o carpeta que ejecuta la versión actual; las distintas copias HTML pueden ser prototipos o revisiones, no necesariamente la producción.
- Revisar documentación y pruebas existentes, si las hay.
- Enumerar dependencias, almacenamiento local, autenticación y servicios externos que realmente utiliza el código presente.
- Si una especificación está incompleta o varias versiones discrepan, pedir la decisión concreta en lugar de inventarla.

## Al terminar una tarea

- Resumir cambios y archivos involucrados.
- Explicar cómo probarlos.
- Señalar riesgos o funcionalidades que no se pudieron verificar.
- Guardar una nota breve en `docs/ESTADO_MAREA.md` si existe; no alterar ni borrar el historial de requisitos.

## Documentación que debe acompañar al proyecto

- `README.md`: qué es MAREA, cómo ejecutar el proyecto y qué versión está vigente.
- `docs/ESTADO_MAREA.md`: funcionalidades implementadas, pendientes, decisiones y errores conocidos.
- `docs/HISTORIAL_PROMPTS.md`: transcripción de **prompts originales que la autora haya decidido conservar**, ordenados cronológicamente. No inventar prompts ni asumir acceso a conversaciones de otras cuentas.

## Advertencia

El historial completo de conversaciones con Codex **no se incorpora automáticamente** a GitHub. Para conservarlo literalmente, la autora debe copiar o exportar los mensajes relevantes, revisar que no contengan información privada y agregarlos por separado a `docs/HISTORIAL_PROMPTS.md`.
